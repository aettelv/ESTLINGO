export class about{
    
    constructor(){
        this.message = "Information about project! (page:about)"
    }
}