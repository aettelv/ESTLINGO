export class about{
    
    constructor(){
        this.message = "ESTLINGO is the easyest way to learn Estonian. "
		this.easy = "Learning language by games, that are easy to understand. Picuters help to memorize words better and make connections that are afterwards easy to bind."
		this.fast = "You are having a coffee break? Good, then you have more than enough time to play one of our games and educate yourself."
		this.family = "Language learning by games is so easy, that eaven kids can learn Estonian. Why not play language games with the whole family?"
		this.game = "You love games and puzzels? That is the right place for you!"
    }
}