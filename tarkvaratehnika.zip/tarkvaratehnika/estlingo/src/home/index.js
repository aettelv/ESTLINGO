export class Home{
    
    constructor(){
        this.h1 = "Welcome to Estlingo!"
		this.message="Learn Estonian in a playful way!"
    }
}