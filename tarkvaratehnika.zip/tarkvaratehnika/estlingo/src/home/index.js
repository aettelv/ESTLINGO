export class Home{
    
    constructor(){
        this.message = "Welcome to Estlingo! (page: home)"
    }
}