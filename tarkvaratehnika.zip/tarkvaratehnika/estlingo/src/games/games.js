export class games{
    
    constructor(){
        this.h1 = "Select equivalent"
		this.h2 = "Type equivalent"
    }
}