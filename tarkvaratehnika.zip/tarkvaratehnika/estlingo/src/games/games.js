export class games{
    
    constructor(){
        this.h1 = "Select equivalent"
		this.h2 = "Type equivalent"
    }
    
    checkAnswer(choice){
        if (choice == 'Oun'){
            this.answer = "True"
        } else {
            this.answer = "False"
        }
    }
}