export class App {
configureRouter(config, router) {
    this.router = router;
    config.title = 'My Aurelia äpp';

    config.map([
      { route: ['', 'home'],       name: 'home',       moduleId: 'home/index', title: "Main page", nav: true },
      { route: 'games', name: 'games',  moduleId: 'games/games', title: "Games",  nav: true },
	  { route: 'about', name: 'about', moduleId: 'about/about', title:"About", nav: true },
      { route: 'register', name: 'register', moduleId: 'register/register', title:"Register", nav: true }
    ]);
  }
}