define('app',['exports'], function (exports) {
    'use strict';

    Object.defineProperty(exports, "__esModule", {
        value: true
    });

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var App = exports.App = function () {
        function App() {
            _classCallCheck(this, App);

            this.message = 'This is message from app.js! Website elements do NOT go here! ';
        }

        App.prototype.configureRouter = function configureRouter(config, router) {
            this.router = router;
            config.title = 'Estlingo';
            config.map([{ route: ['', 'home'], name: 'home', moduleId: 'home/index' }, { route: 'games', name: 'games', moduleId: 'games/games', nav: true }, { route: 'about', name: 'about', moduleId: 'about/about', nav: true }, { route: 'register', name: 'register', moduleId: 'register/register', nav: true }]);
        };

        return App;
    }();
});
define('environment',["exports"], function (exports) {
  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = {
    debug: true,
    testing: true
  };
});
define('main',['exports', './environment'], function (exports, _environment) {
  'use strict';

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.configure = configure;

  var _environment2 = _interopRequireDefault(_environment);

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
      default: obj
    };
  }

  Promise.config({
    warnings: {
      wForgottenReturn: false
    }
  });

  function configure(aurelia) {
    aurelia.use.standardConfiguration().feature('resources');

    if (_environment2.default.debug) {
      aurelia.use.developmentLogging();
    }

    if (_environment2.default.testing) {
      aurelia.use.plugin('aurelia-testing');
    }

    aurelia.start().then(function () {
      return aurelia.setRoot();
    });
  }
});
define('about/about',["exports"], function (exports) {
    "use strict";

    Object.defineProperty(exports, "__esModule", {
        value: true
    });

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var about = exports.about = function about() {
        _classCallCheck(this, about);

        this.message = "Information about project! (page:about)";
    };
});
define('home/index',["exports"], function (exports) {
    "use strict";

    Object.defineProperty(exports, "__esModule", {
        value: true
    });

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var Home = exports.Home = function Home() {
        _classCallCheck(this, Home);

        this.message = "Welcome to Estlingo! (page: home)";
    };
});
define('games/games',["exports"], function (exports) {
    "use strict";

    Object.defineProperty(exports, "__esModule", {
        value: true
    });

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var games = exports.games = function () {
        function games() {
            _classCallCheck(this, games);

            this.message = "Games go here! (page:games)";
        }

        games.prototype.checkAnswer = function checkAnswer(choice) {
            if (choice == 'Oun') {
                this.answer = "True";
            } else {
                this.answer = "False";
            }
        };

        return games;
    }();
});
define('register/register',["exports", "aurelia-fetch-client"], function (exports, _aureliaFetchClient) {
    "use strict";

    Object.defineProperty(exports, "__esModule", {
        value: true
    });
    exports.Register = undefined;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    var Register = exports.Register = function () {
        function Register() {
            _classCallCheck(this, Register);

            this.userData = {};

            this.message = "Register user here! (page: register)";
        }

        Register.prototype.addUser = function addUser() {
            var client = new _aureliaFetchClient.HttpClient();

            client.fetch('http://localhost:8080/users/add', {
                'method': "POST",
                'body': (0, _aureliaFetchClient.json)(this.userData)
            }).then(function (response) {
                return response.json();
            }).then(function (data) {
                console.log("Server saatis " + data.username);
            });

            console.log("Method executed!");
        };

        return Register;
    }();
});
define('resources/index',["exports"], function (exports) {
  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.configure = configure;
  function configure(config) {}
});
define('text!app.html', ['module'], function(module) { module.exports = "<template><router-view></router-view><div>------------------------------------------------------------------------------------------------------------<div>${message}<br>(page: app.html)</div><br><div>Different pages:<ul><li><a href=\"http://localhost:9000\"><b>Home:</b> http://localhost:9000</a></li><li><a href=\"http://localhost:9000/#/games\"><b>Games:</b> http://localhost:9000/#/games</a></li><li><a href=\"http://localhost:9000/#/about\"><b>About:</b> http://localhost:9000/#/about</a></li><li><a href=\"http://localhost:9000/#/register\"><b>Register user:</b> http://localhost:9000/#/register</a></li></ul></div>------------------------------------------------------------------------------------------------------------</div></template>"; });
define('text!about/about.html', ['module'], function(module) { module.exports = "<template>${message}</template>"; });
define('text!games/games.html', ['module'], function(module) { module.exports = "<template><div>${message}</div><br><div><b>Game 1:</b><div><img src=\"src/games/images/Apple.png\" alt=\"Error loading image! Image: Apple\" style=\"height:50px\"><br><button click.trigger=\"checkAnswer('Oun')\">Õun</button><br><button click.trigger=\"checkAnswer('Pirn')\">Pirn</button><br><button click.trigger=\"checkAnswer('Banaan')\">Banaan</button></div>${answer}</div></template>"; });
define('text!home/index.html', ['module'], function(module) { module.exports = "<template>${message}</template>"; });
define('text!register/register.html', ['module'], function(module) { module.exports = "<template>${message}<form id=\"userform\" submit.delegate=\"addUser()\"><div><label for=\"username\">Username:</label><input id=\"username\" type=\"text\" name=\"username\" value.bind=\"userData.username\"></div><div><label for=\"password\">Password:</label><input id=\"password\" type=\"password\" name=\"password\" value.bind=\"userData.password\"></div><div><label for=\"eMail\">E-mail:</label><input id=\"eMail\" type=\"text\" name=\"eMail\" value.bind=\"userData.eMail\"></div><input type=\"submit\" name=\"RegisterUserSubmit\" value=\"Register user\"></form></template>"; });
//# sourceMappingURL=app-bundle.js.map